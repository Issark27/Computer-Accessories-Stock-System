
public enum ConnectivityType {
	WIRED,
	WIRELESS;
	
}
