
public enum UserRole {
	ADMIN,
	CUSTOMER
	
}
