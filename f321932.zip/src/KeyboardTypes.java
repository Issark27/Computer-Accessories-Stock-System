
public enum KeyboardTypes {
	FLEXIBLE,
	STANDARD,
	GAMING
}
