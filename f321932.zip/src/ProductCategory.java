
public enum ProductCategory {
    MOUSE,
    KEYBOARD;
	
}