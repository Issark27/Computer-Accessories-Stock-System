
public enum MouseTypes {
	STANDARD,
	GAMING
}
