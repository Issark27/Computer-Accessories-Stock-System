
public enum Layout {
	UK,
	US
}
